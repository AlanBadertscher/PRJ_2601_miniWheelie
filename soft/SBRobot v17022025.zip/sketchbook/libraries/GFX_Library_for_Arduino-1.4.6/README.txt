GFX_Library_for_Arduino v1.4.6: download from https://github.com/moononournation/Arduino_GFX
or use the Arduino IDE's library manager.
